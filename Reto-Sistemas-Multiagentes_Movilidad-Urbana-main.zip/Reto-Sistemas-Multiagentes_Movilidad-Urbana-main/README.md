# Reto-Sistemas-Multiagentes_Movilidad-Urbana
* Juan Daniel Rodríguez Oropeza A01411625
* Sergio Hiroshi Carrera A01197964
* Jesús Sebastián Jaime Oviedo A01412442
* Jackeline Conant A01280544
* William Frank Monroy Mamani A00829796
* Premsyl Pilar A01760915