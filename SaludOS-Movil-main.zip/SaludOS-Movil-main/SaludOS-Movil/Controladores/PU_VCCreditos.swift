//
//  PU_VCCreditos.swift
//  SaludOS-Movil
//
//  Created by Alumno on 17/10/22.
//

import UIKit

class PU_VCCreditos: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    
    
    @IBAction func Regresar(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
}
